
/*
    Name    :- B.A.I.Gayal
    St.Num  :- SE/2016/010
    Purpose :- Solution for the Dining Philosphers problem
    Date    :- 2019.05.05

 */

package com.company;

import java.util.concurrent.Semaphore;

import static com.company.Philosopher.N;
import static com.company.Philosopher.fork;

public class Main {

    public static void main(String[] args) {
        System.out.println("Begin");

        for (int f = 0; f < N; f++) {
            fork[f] = new Semaphore(1, true);
        }

        Philosopher[] philosopher = new Philosopher[N];
        for (int me = 0; me < N; me++) {

            int myneighbor = me + 1;
            if (myneighbor == N) myneighbor = 0;


            philosopher[me] = new Philosopher(me, fork[me], fork[myneighbor]);
    }


        for (int i = 0; i < N; i++) {
            philosopher[i].start();
        }


        for (int i = 0; i < N; i++) {
            try {
                philosopher[i].join();
            } catch(InterruptedException ex) { }
        }


        System.out.println("Done");
    }
}

