package com.company;

import java.util.Random;
import java.util.concurrent.Semaphore;

public class Philosopher extends Thread{

    private static final Random rand = new Random();
    private static int event=0;
    final static int N = 5;
    public static Semaphore[] fork = new Semaphore[N];
    private int oneOnTop = N;


    private int id;
    private Semaphore myFork;
    private Semaphore myNeighborsFork;
    private int meals = 10;


    public Philosopher(int i, Semaphore fork1, Semaphore fork2)
    {
        id = i;
        myFork = fork1;
        myNeighborsFork = fork2;
    }


    private void postMsg(String str) {
        System.out.printf("%d %d. Chopsitcks left: %d. Philosopher %d %s\n",
                System.currentTimeMillis(), ++event, getTopOne(), id, str);
    }


    private void pause()
    {
        try
        {
            sleep(rand.nextInt(4000));
        } catch (InterruptedException e){}
    }


    private void think()
    {
        postMsg("is thinking");
        pause();
    }

    private synchronized void takeOne()
    {
        oneOnTop--;
    }

    private synchronized void putBack()
    {
        oneOnTop++;
    }



    private synchronized int getTopOne()
    {
        return oneOnTop;
    }


    private void trytoeat()
    {
        if (getTopOne() < 2){
            postMsg("is waiting for ennough chopsticks to be on the table");
        } else {
            postMsg("is hungry and is trying to pick up two chopsticks");
        }
        pause();
        try {

            takeOne();
            myFork = fork[getTopOne() - 1];
            myFork.acquire();

            takeOne();
            myNeighborsFork = fork[getTopOne() - 1];
            if (!myNeighborsFork.tryAcquire()) {

                postMsg(">>>> was not able to get a second chopstick");
                return;
            };

            postMsg("picked up two chopsticks and is eating meal #" + (10 - --meals));
            pause();


            postMsg("puts down his chopsticks");
            putBack();
            myNeighborsFork.release();

        } catch (InterruptedException e) {
            postMsg("was interrupted while waiting for his fork");
        }
        finally {
            putBack();
            myFork.release();
        }
    }


    @Override
    public void run()
    {
        while (meals > 0)
        {
            think();
            trytoeat();
        }
    }
}
