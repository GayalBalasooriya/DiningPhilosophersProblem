package com.company;

import java.util.concurrent.Semaphore;

import static com.company.Philosopher.N;
import static com.company.Philosopher.fork;

public class Main {

    public static void main(String[] args) {
        System.out.println("Begin");

        //final int N = 5; // five philosophers, five forks

        // Create the forks, 1 fork per philosopher
        //Semaphore[] fork = new Semaphore[N];
        for (int f = 0; f < N; f++) {
            // each fork is a single resource
            fork[f] = new Semaphore(1, true);
        }

        // Create the philosophers, pass in their forks
        Philosopher[] philosopher = new Philosopher[N];
        for (int me = 0; me < N; me++) {
            // determine my right-hand neighbor's ID
            int myneighbor = me + 1;
            if (myneighbor == N) myneighbor = 0;

            // Initialize each philosopher (no pun intended)
            philosopher[me] = new Philosopher(me, fork[me], fork[myneighbor]); // :)/>
        }

        // Start the philosophers
        for (int i = 0; i < N; i++) {
            philosopher[i].start();
        }

        // Wait for them to finish
        for (int i = 0; i < N; i++) {
            try {
                philosopher[i].join();
            } catch(InterruptedException ex) { }
        }

        // All done
        System.out.println("Done");
    }
}

